<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Search extends MY_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('ws_search_model');
		$this->load->helper('url');
		$this->load->helper('text');
		
		$this->data['printemail'] = $this->load->view('includes/print-email-share', '', TRUE);
	}
	
	/**
	 * search_submit function.
	 * 
	 * @access public
	 * @return void
	 */
	public function results() {
		$this->data['list'] = $this->ws_search_model->set_search_results();
		$this->data['search_list'] = $this->load->view('content/search-list', $this->data, TRUE);
		//print_r($this->input->post());
		$this->data['list_of_keywords'] = @implode(', ', $this->input->post());
		//echo $this->data['list_of_keywords'];
		
		//print_r($this->data['list']);
		
		$this->set_wrapper_elements('html/search-results');
		
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */