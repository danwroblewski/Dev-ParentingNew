<div id="printemailtray">
				<div class="printtrayleft"><div class="fb-like" data-send="false" data-width="450" data-show-faces="false"></div> </div>
				<div class="printtrayright"><a href="#" class="btn-printcontent"><span>Print</span></a><a href="#" class="btn-emailcontent"><span>E-mail</span></a><span class='st_sharethis' displayText='' style="float:right;"></span></div>
</div>