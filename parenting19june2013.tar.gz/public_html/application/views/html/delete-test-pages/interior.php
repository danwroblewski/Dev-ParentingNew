
<!-- =========================== CONTENT =========================== -->
<div class="container">
	<div class="sixteen contentcolumn columns alpha omega">
		<img src="/img/interior-topblur.png" width="100%" height="39" />
		<div class="twelve incontent columns">
			<h1>This is the title of a page</h1>
			<div id="printemailtray">
				<div class="printtrayleft"><span class='st_sharethis' displayText='ShareThis'></span></div>
				<div class="printtrayright"><a href="#" class="btn-printcontent"><span>Print</span></a><a href="#" class="btn-emailcontent"><span>E-mail</span></a></div>
			</div>
			<h2>Search Results</h2>
			<p><a href="#" class="searchresult">Intensive Toilet Training</a></br />
			Sometimes the 7 P plan is not enough. This often happens when continence is needed now or at least in the next week or two. Reasons for...</p>
			<p><a href="#" class="searchresult">Potty Training</a><br />
			It is normal for siblings to compete for their parents’ attention and time. Unfortunately, children may use inappropriate behaviors...
			<p><a href="#" class="searchresult">I'm Not Going to Take Anymore</a><br />
			When your child is angry and throws a tantrum, do you feel as though you have no control? Thoughts of helplessness can creep into the mind...
			<p><a href="#" class="searchresult">Potty Training More</a><br />
			Sunscreen and Sun Safety It is well known that prolonged, unprotected exposure to the sun puts people at risk for skin cancer. The regular...
			<p><a href="#" class="searchresult">Potty Training</a><br />
			We cannot always protect our children from every possible threat, but we can help them feel more secure. One way to do this is by making a...
			<p><a href="#" class="searchresult">AnotherPotty Training</a><br />
			The thought of sharing mom and dad with a baby brother or sister can be unsettling for a young child. After all, your little one has had...
			<p><a href="#" class="searchresult">More About Potty Training and Potty’s in General</a><br />
			Getting out of the house on time with children dressed, teeth brushed, tummies filled and backpacks in hand can be challenging. Getting out... 
			<p><a href="#" class="searchresult">Potty Training More</a><br />
			Sunscreen and Sun Safety It is well known that prolonged, unprotected exposure to the sun puts people at risk for skin cancer. The regular...
			</p>
			<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
			<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, <a href="#">totam rem aperiam</a>, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>
			<ul>
				<li>Example of a bullet</li>
				<li>Example of a bullet</li>
				<li>Example of a bullet</li>
				<li>Example of a bullet <a href="#">with a link</a></li>
			</ul>
			<p><a href="#">Example of a link</a></p>
		</div>
		<div class="four inyellowright columns">
			<img src="/img/ad-boystown.jpg" width="100%" height="" />
			<a href="#" class="btn-hotline"><span>Hotline</span></a><br clear="all">
			<div class="btpress-back">
				<a href="#" class="btn-visitwebsite"><span>Visit Website</span></a>
			</div>
		</div>
	</div>
</div>

