
<!-- JL  -- INTERIOR AREA -->	
	<div class="container">
		<div class="sixteen contentcolumn columns alpha omega">
			<img src="/img/interior-topblur.png" width="100%" height="39" />
			<div class="twelve incontent columns paginated-content">
				<h1>Search Results</h1>
				<?php print $printemail; ?>

				<?php echo $search_list; ?>
				
				<p>&nbsp;</p>
				<div class="page_navigation"></div>
			</div>
			
			<div class="four inyellowright columns">
				<img src="/img/ad-boystown.jpg" width="100%" height="" />
			</div>
		</div>
	</div>
<!-- END INTERIOR -->