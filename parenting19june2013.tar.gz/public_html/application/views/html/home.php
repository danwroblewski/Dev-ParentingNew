<!-- =========================== ROTATOR FEATURE =========================== -->
	<div class="container">
		<div id="rotators">
			<div id="rotator-subad">
				<a href="#" class="btn-moreaboutthistopic"><span>More on This Topic</span></a>
			</div>
			
			<div class="rotator-ads" style="height:267px;">
				<div class="each-ad">
					<div class="leftcontent content">
						<h1>Prepping for a Safe &amp; Sane Prom Night</h1>
						<p>Town Expert, Laura Buddenberg, shares tips on how to have a memory -filled and grief-free experience for both teens and parents.</p>
					</div>
					<div class="image-content">
						<img src="/img/homepage-ads/ad-safeandsane2.png" />
					</div>
				</div>
				
				<div class="each-ad">
					<div class="leftcontent content">
						<h1>Ask a Question</h1>
						<p>Content content content</p>
					</div>
					<div class="image-content">
						<img src="/img/homepage-ads/ad-safeandsane2.png" />
					</div>
				</div>
				
				<div class="each-ad">
					<div class="leftcontent content">
						<h1>Parenting Guides</h1>
						<p>Content content contentContent content contentContent content contentContent content content</p>
					</div>
					<div class="image-content">
						<img src="/img/homepage-ads/ad-safeandsane2.png" />
					</div>
				</div>
			</div>
			
			<div class="pager-container">
				<ul class="pager-nav"></ul>
			</div>
			
	<!-- =========================== MOBILE AD HERE =========================== -->
			<div class="mainad-mobile">
				<img src="/img/homepage-ads/ad-safeandsane.png" width="767" height="264" alt="Prepping for a Safe and Sane Prom Night" />
			</div>
			
		</div><!-- end id="rotators" -->
		
		<div class="divider-long"><img src="/img/divider-long.png" width="100%" /></div>
	</div><!-- end container -->


<!-- JL  -- SUB AD AREA -->
	<div class="container">
		<div id="subbox">
			<div class="eleven box-nav columns alpha omega">
				<ul>
					<li class="boxnav-fg on"><a href="#tab-1">Featured Guide</a></li>
					<li class="boxnav-tt"><a href="#tab-2">Timely Topics</a></li>
					<li class="boxnav-oe"><a href="#tab-3">Our Experts</a></li>
				</ul>
			</div>
			<div class="five newsletterboxhead columns">
				E-NEWS SIGN UP
			</div>
		</div>
		
		
		
<!-- =========================== TABS CONTENT =========================== -->
		<div id="subboxcontent">
			<!-- =========================== featured guide =========================== -->
			<div class="eleven homeboxcontent columns alpha omega tabs active" id="tab-1">
				<img src="/img/home-guidephoto.png" width="205" height="128" alt="Back to School" class="alignright padright" />
				<h1>Back to School</h1>
				<p>Parenting.org is your go-to guide for all things Back To School. From toddlers to teens, we have the expert advice you need.  <a href="#">READ MORE &rsaquo;&rsaquo;</a></p>
					<div class="columsy">
						<ul class="new">
							<li class="columsy-art"><a href="#">Choosing the Right Preschool</a></li>
							<li class="columsy-art"><a href="#">Is Your Child Ready for Kindergarten?</a></li>
							<li class="columsy-art"><a href="#">Is my child too Busy?</a></li>
							<li class="columsy-tips"><a href="#">5 Tips to Bully Proof Your Child</a></li>
						</ul>
					</div>
					<div class="columsy">
						<ul class="new">
							<li class="columsy-tips"><a href="#">Choosing the Right Preschool</a></li>
							<li class="columsy-video"><a href="#">Is Your Child Ready for Kindergarten?</a></li>
							<li class="columsy-video"><a href="#">Is my child too Busy?</a></li>
							<li class="columsy-video"><a href="#">5 Tips to Bully Proof Your Child</a></li>
						</ul>
					</div><br clear="all">
				<div class="homeboxcontentlinks"><span style="float:left;"><a href="#">More About Back to School Guide</a></span><span style="float:right;"><a href="#">All Guides &rsaquo;&rsaquo;</a></span><br clear="all"></div>
			</div>
			
			<!-- =========================== timely topics =========================== -->
			<div class="eleven homeboxcontent columns alpha omega tabs hide" id="tab-2">
				<h1>Competing With Character</h1>
				<p>Participating in organized youth sports is about much more than just winning; it's about building integrity and developing lessons that will serve a useful purpose well into adulthood.</p>
					<div class="columsy">
						<ul class="new">
							<li class="columsy-art"><a href="#">Choosing the Right Preschool</a></li>
							<li class="columsy-art"><a href="#">Is Your Child Ready for Kindergarten?</a></li>
							<li class="columsy-art"><a href="#">Is my child too Busy?</a></li>
							<li class="columsy-tips"><a href="#">5 Tips to Bully Proof Your Child</a></li>
						</ul>
					</div>
					<div class="columsy">
						<ul class="new">
							<li class="columsy-tips"><a href="#">Choosing the Right Preschool</a></li>
							<li class="columsy-video"><a href="#">Is Your Child Ready for Kindergarten?</a></li>
							<li class="columsy-video"><a href="#">Is my child too Busy?</a></li>
							<li class="columsy-video"><a href="#">5 Tips to Bully Proof Your Child</a></li>
						</ul>
					</div><br clear="all">
				<div class="homeboxcontentlinks"><span style="float:left;"><a href="#">More About Back to School Guide</a></span><span style="float:right;"><a href="#">All Guides &rsaquo;&rsaquo;</a></span><br clear="all"></div>
			</div>
			
			<!-- =========================== our experts =========================== -->
			<div class="eleven homeboxcontent columns alpha omega tabs hide" id="tab-3">
				<img src="/img/home-guidephoto.png" width="205" height="128" alt="Back to School" class="alignright padright" />
				<h1>Meet Our Experts</h1>
				<p>Parenting.org is a resource for those raising children of all ages. Its broad range of useful content is developed by specialist whose expertise runs the gamut of childhood education and development.</p>
					<div class="columsy">
						<ul class="new">
							<li class="columsy-art"><a href="/our-experts/laura-buddenberg">Laura Buddenberg</a></li>
							<li class="columsy-art"><a href="/our-experts/julia-cook">Julia Cook</a></li>
							<li class="columsy-art"><a href="/our-experts/patrick-friman">Dr. Patrick Friman, Ph.D.</a></li>
						</ul>
					</div>
					<div class="columsy">
						<ul class="new">
							<li class="columsy-art"><a href="/our-experts/coach-kush">Coach Kush</a></li>
							<li class="columsy-art"><a href="/our-experts/thomas-reimers">Thomas M. Reimers, Ph.D.</a></li>
							<li class="columsy-art"><a href="/our-experts/connie-schnoes">Connie Schnoes Ph.D.</a></li>
						</ul>
					</div>
					<br clear="all">
					<div class="homeboxcontentlinks">
						<span style="float:left;"><a href="/our-experts">More About Our Experts &rsaquo;&rsaquo;</a></span>
						<br clear="all">
					</div>
			</div>
			
			<div class="five homeboxcontentright columns">
				<div class="newsletterboxcontent">
					<form style="padding:10px 20px;" action="http://envoyinc-main.createsend.com/t/y/s/bdiyul/" method="post" id="subForm">
						<div>
							<label for="name">Name:</label>
							<input style="margin-bottom:10px; width:96%;" type="text" name="cm-name" id="name" placeholder="Name" />
							
							<label for="bdiyul-bdiyul">Email:</label>
							<input style="margin-bottom:10px; width:96%;" type="text" name="cm-bdiyul-bdiyul" id="bdiyul-bdiyul" placeholder="Email" />
							
							<input type="submit" value="Subscribe" />
						</div>
					</form>
				
				
					<!--<form action="http://envoyinc-main.createsend.com/t/y/s/bjifh/" method="post">
			        	<div align="center"><input id="first-name" name="cm-name" class="text" placeholder="Name" type="text" /><input id="bjifh-bjifh" name="cm-bjifh-bjifh" class="text" placeholder="Email Address" type="text" /></div><input type="submit" value="Subscribe" id="sub" name="sub" />
		           	</form>-->
           		</div>
           		<div align="center"><a href="#" class="btn-hotline"><span>Hotline</span></a></div>
			</div><br clear="all">
			
		</div><!-- end subboxcontent -->
	</div><!-- end container -->
	
	<div class="container">
		<div class="sixteen subboxgauss columns"><img src="../img/subbox-gauss.png" width="100%" /></div>
	</div>
	
	
	<!-- =========================== FOUR BOXES =========================== -->
	<div class="container">	
		<div class="four highlight-box-home columns">
			<div class="highlights">
				<img src="/img/icon-checkmark.png" width="89" height="89" />
				<p><a href="#"><span>QUICK TIPS</span><br />
				Read All Quick Tips &rsaquo;&rsaquo;</a></p>
			</div>
		</div>
		
		<div class="four highlight-box-home columns">
			<div class="highlights">
				<img src="/img/icon-articles.png" width="89" height="89" />
				<p><a href="/article"><span>ARTICLES</span><br />
				Search Articles &rsaquo;&rsaquo;</a></p>
			</div>
		</div>
		
		<div class="four highlight-box-home columns iefix">
			<div class="highlights">
				<img src="/img/icon-questionmark.png" width="89" height="89" />
				<p><a href="/questions-and-answers"><span>Q &amp; A'S</span><br />
				Read All Q&amp;A&rsquo;s &rsaquo;&rsaquo;</a></p>
			</div>
		</div>
		
		<div class="four highlight-box-home columns">
			<div class="highlights">
				<img src="/img/icon-videos.png" width="89" height="89" />
				<p><a href="/videos"><span>VIDEOS</span><br />
				Watch All Videos &rsaquo;&rsaquo;</a></p>
			</div>
		</div>
	</div><!-- container -->

</div>
