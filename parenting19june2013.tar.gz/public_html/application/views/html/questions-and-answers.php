<!-- =========================== CONTENT =========================== -->
<div class="container">
	<div class="sixteen contentcolumn columns alpha omega">
		<img src="img/interior-topblur.png" width="100%" height="39" />
		<div class="twelve incontent columns paginated-content">
			<h1>Questions and Answers</h1>
			<?php print $printemail; ?>
			<h2>Search Results</h2>
			<?php echo $questions_and_answers_list; ?>
		</div>
		
		<div class="four inyellowright columns">
			<img src="img/ad-boystown.jpg" width="100%" height="" />
			<a href="#" class="btn-hotline"><span>Hotline</span></a><br clear="all">
			<div class="btpress-back">
				<a href="#" class="btn-visitwebsite"><span>Visit Website</span></a>
			</div>
		</div>
	</div>
</div>

