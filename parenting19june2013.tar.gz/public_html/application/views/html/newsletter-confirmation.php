
<!-- =========================== CONTENT =========================== -->
<div class="container">
	<div class="sixteen contentcolumn columns alpha omega">
		<img src="/img/interior-topblur.png" width="100%" height="39" />
		<div class="twelve incontent columns">
			<h1>Thank you!</h1>
			
			<h2>Newsletter Confirmation</h2>
			<p>Thank you for your subscription! You will now receive the Parenting.org e-newsletter.</p>
			
			
		</div>
		<div class="four inyellowright columns">
			<img src="/img/ad-boystown.jpg" width="100%" height="" />
			<a href="#" class="btn-hotline"><span>Hotline</span></a><br clear="all">
			<div class="btpress-back">
				<a href="#" class="btn-visitwebsite"><span>Visit Website</span></a>
			</div>
		</div>
	</div>
</div>

