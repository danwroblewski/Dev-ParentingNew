
<ul class="listed-content content">
	<?php foreach($list as $item):
		$url_alias = explode("/",$item->views_url_alias_node_alias);
	?>
	<li>
		<h3><a href="<?php echo $this->uri->segment(1) . '/' . $url_alias[1]; ?>"><?php echo $item->node_title; ?></a></h3>
		<?php echo word_limiter(ascii_to_entities(strip_tags($item->body->summary, 35))); ?>
		<p>&nbsp;</p>
	</li>
	<?php endforeach; ?>
</ul>

<div class="page_navigation"></div>
