
<!-- =========================== CONTENT =========================== -->
<div class="container">
	<div class="sixteen contentcolumn columns alpha omega">
		
		<div class="sixteen landcsp columns alpha omega">
				<div class="landhead">GUIDES</div>
				<h1>Parenting Can Be Tough.<br />
				We Can Help</h1>
				<div class="landingbintwo">
					Parents learn logical strategies and proven methods developed by Boys Town.
					<a href="#" class="btn-landreadmore"><span>Read More</span></a>
				</div>
				<div class="landingbintwo">
					Common Sense Parenting<sup>&reg;</sup> offers a variety of classes to help parents succeed.
					<a href="#" class="btn-landseeclasses"><span>See Classes</span></a>
				</div>
		</div>
		<div class="landing-top-container-long csp">
				<h1>Parenting Can Be Tough. We Can Help</h1>
				<p>Parents learn logical strategies and proven methods developed by Boys Town.<br /><a href="#" class="btn-landreadmore"><span>Read More</span></a>
				</p>
				<p>Common Sense Parenting<sup>&reg;</sup> offers a variety of classes to help parents succeed.<br /><a href="#" class="btn-landseeclasses"><span>See Classes</span></a></p>
		</div>
		
		<div class="two-thirds incontent column">
			
			<h1 style="margin-top:25px;"><?php echo $item->title; ?></h1>
			
			<?php print $printemail; ?>



			<div class="content">
				<div id="tabbed-content">
		<!-- =========================== ARTICLES PORTION =========================== -->
					<div class="articles-list tabs active" id="tab-1">
						<ul class="listed-content content">
							<?php foreach($list as $item): $url_alias = explode("/",$item->link); ?>
								<li>
									<h3><a href="/<?php echo url_title(strtolower($item->type)) . '/' . $url_alias[5]; ?>" class="searchresult"><?php echo ascii_to_entities($item->title); ?></a></h3>
									<p><?php echo word_limiter(ascii_to_entities(strip_tags($item->node->body->und[0]->value)), 10); ?></p>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
					
		<!-- =========================== QUESTIONS PORTION =========================== -->
					<div class="questions-list tabs hide" id="tab-2">
						<ul class="listed-content content">
							<?php foreach($list as $item): $url_alias = explode("/",$item->link); ?>
								<li>
									<h3><a href="/<?php echo url_title(strtolower($item->type)) . '/' . $url_alias[5]; ?>" class="searchresult"><?php echo ascii_to_entities($item->title); ?></a></h3>
									<p><?php echo word_limiter(ascii_to_entities(strip_tags($item->node->body->und[0]->value)), 10); ?></p>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
					
		<!-- =========================== QUICK TIPS PORTION =========================== -->
					<div class="quicktips-list tabs hide" id="tab-3">
						<ul class="listed-content content">
							<?php foreach($list as $item): $url_alias = explode("/",$item->link); ?>
								<li>
									<h3><a href="/<?php echo url_title(strtolower($item->type)) . '/' . $url_alias[5]; ?>" class="searchresult"><?php echo ascii_to_entities($item->title); ?></a></h3>
									<p><?php echo word_limiter(ascii_to_entities(strip_tags($item->node->body->und[0]->value)), 10); ?></p>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
					
		<!-- =========================== VIDEOS PORTION =========================== -->
					<div class="videos-list tabs hide" id="tab-4">
						<ul class="listed-content content">
							<?php foreach($list as $item): $url_alias = explode("/",$item->link); ?>
								<li>
									<h3><a href="/<?php echo url_title(strtolower($item->type)) . '/' . $url_alias[5]; ?>" class="searchresult"><?php echo ascii_to_entities($item->title); ?></a></h3>
									<p><?php echo word_limiter(ascii_to_entities(strip_tags($item->node->body->und[0]->value)), 10); ?></p>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>
				</div><!-- end tabbed-content -->
			</div><!-- end content -->
			
			<div id="tablinks-container">
				<div class="four box-nav columns alpha omega">
					<ul>
						<li class="tab-links quick-tips">
							<div class="highlight-box-home">
								<div class="highlights">
									<img src="/img/icon-checkmark.png" width="89" height="89" />
									<p><a href="#tab-3"><span>QUICK TIPS</span><br />
									Read All Quick Tips &rsaquo;&rsaquo;</a></p>
								</div>
							</div>
						</li>
						
						<li class="tab-links questions">
							<div class="highlight-box-home">
								<div class="highlights">
									<img src="/img/icon-questionmark.png" width="89" height="89" />
									<p><a href="#tab-2"><span>Q &amp; A'S</span><br />
									Read All Q&amp;A&rsquo;s &rsaquo;&rsaquo;</a></p>
								</div>
							</div>
						</li>
						
						<li class="tab-links articles on">
							<div class="highlight-box-home">
								<div class="highlights">
									<img src="/img/icon-articles.png" width="89" height="89" />
									<p><a href="#tab-1"><span>ARTICLES</span><br />
									Search Articles &rsaquo;&rsaquo;</a></p>
								</div>
							</div>
						</li>
						
						<li class="tab-links videos">
							<div class="highlight-box-home">
								<div class="highlights">
									<img src="/img/icon-articles.png" width="89" height="89" />
									<p><a href="#tab-4"><span>Videos</span><br />
									Watch All Videos &rsaquo;&rsaquo;</a></p>
								</div>
							</div>
						</li>
						
						<!--
						<li class="tab-links quick-tips"><a href="#tab-3">Quick Tips</a></li>
						<li class="tab-links questions"><a href="#tab-2">Q &amp; A's</a></li>
						<li class="tab-links articles on"><a href="#tab-1">Articles</a></li>
						<li class="tab-links videos"><a href="#tab-4">Videos</a></li>
						-->
					</ul>
				</div>
			</div>
			
			
			
		</div><!-- end two-thirds incontent column -->
		
		<div class="one-third landingright column">
		    <div id="navigation-back">
		    	<div class="secondary">
		    		<ul class="landing">
		    			<li><a href="/guides/media-and-parenting"><h3>A Parent's Guide to</h3><br />Media and Parenting</a></li>
		    			<li><a href="/guides/youth-sports"><h3>A Parent's Guide to</h3><br />Youth Sports</a></li>
		    			<li><a href="/guides/sleep-issues"><h3>A Parent's Guide to</h3><br />Sleep Issues</a></li>
		    			<li><a href="/guides/bullying"><h3>A Parent's Guide to</h3><br />Bullying</a></li>
		    			<li><a href="/guides/relationships-dating"><h3>A Parent's Guide to</h3><br />Relationships/Dating</a></li>
		    			<li><a href="/guides/potty-training"><h3>A Parent's Guide to</h3><br />Potty Training</a></li>
		    			<li><a href="/guides/communicating-with-teens"><h3>A Parent's Guide to</h3><br />Communicating with Teens</a></li>
		    			<li><a href="/guides/harmful-behaviors"><h3>A Parent's Guide to</h3><br />Harmful Behaviors</a></li>		
		    		</ul>
		    	</div>
		    </div>
		    <br clear="all">
		    <div align="center"><a href="#" class="btn-hotline"><span>Hotline</span></a></div>
		    <br clear="all">
		</div>

	</div>
</div>