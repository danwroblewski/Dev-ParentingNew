
<!-- =========================== CONTENT =========================== -->
<div class="container">
	<div class="sixteen contentcolumn columns alpha omega">
		<img src="/img/interior-topblur.png" width="100%" height="39" />
		<div class="twelve incontent columns">
			
			<h1><?php echo $item->title; ?></h1>
			
			<?php print $printemail; ?>
			
			<div class="content">
				<?php echo $item->body->und[0]->value; ?>
			</div>
			
			<img src="/img/printtray_blurtop.png" width="100%" />
			<div class="twelve contentnav columns">
				<div class="contentnavleft"><a href="#" class="btn-back-articles"><span>Back</span></a></div>  
				<div class="contentnavright"><a href="#" class="btn-askaquestion"><span>Ask A Question</span></a></div>  
			</div>
			<img src="/img/printtray_blurbot.png" width="100%">
			
<!-- =========================== THREE BOXES =========================== -->
			<div class="four highlight-box-home columns omega">
				<div class="highlights">
					<img src="/img/icon-checkmark.png" width="89" height="89" />
					<p><a href="#"><span>QUICK TIPS</span><br />
					Read All Quick Tips &rsaquo;&rsaquo;</a></p>
				</div>
			</div>
			
			<div class="four highlight-box-home columns alpha omega">
				<div class="highlights">
					<img src="/img/icon-articles.png" width="89" height="89" />
					<p><a href="#"><span>ARTICLES</span><br />
					Search Articles &rsaquo;&rsaquo;</a></p>
				</div>
			</div>
			
			<div class="four highlight-box-home columns alpha omega">
				<div class="highlights">
					<img src="/img/icon-questionmark.png" width="89" height="89" />
					<p><a href="#"><span>Q &amp; A'S</span><br />
					Read All Q&amp;A&rsquo;s &rsaquo;&rsaquo;</a></p>
				</div>
			</div>
			
		</div>
		<div class="four inyellowright columns">
			<img src="/img/ad-boystown.jpg" width="100%" height="" />
			<a href="#" class="btn-hotline"><span>Hotline</span></a><br clear="all">
			<div class="btpress-back">
				<a href="#" class="btn-visitwebsite"><span>Visit Website</span></a>
			</div>
		</div>
	</div>
</div>