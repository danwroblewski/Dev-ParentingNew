<div class="twelve columns">

	<?php if(empty($list)) : ?>
		<h2 style="margin-top:0;">Your search yielded no results</h2>
		<ul>
			  <li>Check if your spelling is correct.</li>
			  <li>Remove quotes around phrases to search for each word individually. <em>bike shed</em> will often show more results than <em>&quot;bike shed&quot;</em>.</li>
			  <li>Consider loosening your query with <em>OR</em>. <em>bike OR shed</em> will often show more results than <em>bike shed</em>.</li>
		</ul>  
	<?php else: ?>
		
		<h2 style="margin-top:0;">Search Results for: <?php echo $list_of_keywords; ?></h2>
		<div style="float:left; width:100%;">
		<h3>Refine your search:</h3>
			<form method="post" action="/search/results" class="search-bar" style="margin:0 0 0 20px;">
			<select name="type">
				<option value=""<?php echo (empty($_POST['type']) || !isset($_POST['type'])) ? ' selected="selected"' : '' ; ?>>&lt;Any&gt;</option>
				<option value="article"<?php echo ($_POST['type'] == 'article' && isset($_POST['type'])) ? ' selected="selected"' : '' ; ?>>Articles</option>
				<option value="ask_an_expert"<?php echo ($_POST['type'] == 'ask_an_expert' && isset($_POST['type'])) ? ' selected="selected"' : '' ; ?>>Ask An Expert</option>
			</select>
			<select name="age">
				<option value=""<?php echo (empty($_POST['age']) || !isset($_POST['age'])) ? ' selected="selected"' : '' ; ?>>Browse by Age</option>
				<option value="Toddlers"<?php echo ($_POST['age'] == 'Toddlers' && isset($_POST['age'])) ? ' selected="selected"' : '' ; ?>>Toddlers</option>
				<option value="Early Childhood"<?php echo ($_POST['age'] == 'Early Childhood' && isset($_POST['age'])) ? ' selected="selected"' : '' ; ?>>Early Childhood</option>
				<option value="Tweens"<?php echo ($_POST['age'] == 'Tweens' && isset($_POST['age'])) ? ' selected="selected"' : '' ; ?>>Tweens</option>
				<option value="Adolescence/Teens"<?php echo ($_POST['age'] == 'Adolescence/Teens' && isset($_POST['age'])) ? ' selected="selected"' : '' ; ?>>Adolescence/Teens</option>
			</select>
			
			<input type="hidden" name="search_query" value="<?php echo $_POST['search_query']; ?>">
			
			<input value="Refine" type="submit" />
			</form>
		</div>
		<ul class="listed-content content">
		<?php foreach($list as $item):
			$url_alias = explode("/",$item->link);
		?>
		<li>
			<h3><a href="/<?php echo url_title(strtolower($item->type)) . '/' . $url_alias[5]; ?>" class="searchresult"><?php echo ascii_to_entities($item->title); ?></a></h3>
			<p><?php echo word_limiter(ascii_to_entities(strip_tags($item->node->body->und[0]->value)), 20); ?></p>
		</li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
