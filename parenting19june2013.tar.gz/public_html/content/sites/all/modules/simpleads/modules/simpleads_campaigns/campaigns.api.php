<?php

/**
 * @file
 * SimpleAds Campaigns API.
 */

/**
 * Ad Compagins completes
 * @param object $node
 */
function hook_simpleads_campaign_complete($node) {}